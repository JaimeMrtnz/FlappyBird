using System;

[Serializable]
public class InitialUserData 
{
    public string SoftCurrency;
    public string HardCurrency;
    public string StoreId;
    public string CatalogVersion;
}
